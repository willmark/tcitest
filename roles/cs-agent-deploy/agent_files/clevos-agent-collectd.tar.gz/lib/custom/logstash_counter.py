#!/usr/bin/env python

import argparse
import datetime
import json
import os
import socket
import subprocess

# Do not rely on this, as the path may change between debian releases.
# Call the plugin with --base-path option that is set by init script during
# initial run.
EXT_AGENT_BASE = '/lib/live/mount/medium/persistent/external-agent-multi/current/'


def read_current_bytes(filename):
    # sincedb line format: #inode #device_major #device_minor #byte_offset
    # Add all the byte_offsets to return cumulative total
    cumulative_bytes = 0

    try:
        with open(filename) as fh:
            for line in fh.readlines():
                cumulative_bytes += int(line.split()[-1])
    except:
        pass

    return cumulative_bytes


def get_logfiles(base_path):
    # Files read by logstash have matching .sincedb_FILENAME where logstash agent is installed.
    # For example '.sincedb_platform.log' for logfile named platform.log
    return [logfile for logfile in os.listdir(base_path) if '.sincedb_' in logfile]


def get_byte_counts(config):
    byte_counts = {}
    base_path = config['base_path']

    for logfile in get_logfiles(os.path.join(base_path, config['logstash_agent_name'])):
        current_count = read_current_bytes(os.path.join(base_path, config['logstash_agent_name'], logfile))
        byte_counts[logfile.replace('.sincedb_', '')] = current_count

    return byte_counts


def derive_sl_config():
    """
    :return: A dictionary with SL specific parameters derived from the name of logstash agent. Not proud of this.
    """
    sl_config = dict(node_type='', datacenter='')

    try:
        agents = json.loads(subprocess.check_output(['eaclient', '-l']))
        for agent in agents:
            if 'logstash' in agent['name']:
                # It will be something like 'logstash_cs_uat_sjc03' or 'logstash_cs_dal09'
                params = agent['name'].split('_', 2)
                sl_config['logstash_agent_name'] = agent['name']
                sl_config['node_type'] = params[1]
                sl_config['datacenter'] = params[2]
                break
    except:
        pass

    return sl_config


def main():
    # Ideally, SL specific parameters will be passed as arguments by collectd calling this plugin.
    # In absence of that, use derive_sl_config()
    sl_config = derive_sl_config()
    base_hostname = socket.gethostname()
    base_hostname = base_hostname.split('.')[0] if '.' in base_hostname else base_hostname

    parser = argparse.ArgumentParser()
    parser.add_argument('-H', '--hostname', help='Set hostname',
                        default=base_hostname)
    parser.add_argument('-p', '--base-path', help='Set base path for the external agents',
                        default=EXT_AGENT_BASE)
    parser.add_argument('-d', '--datacenter', help='Set datacenter',
                        default=sl_config['datacenter'])
    parser.add_argument('-n', '--node-type', help='Set node type',
                        default=sl_config['node_type'])
    parser.add_argument('-r', '--reset-counter', help='Reset bytes counter for every new tailed file',
                        action='store_true')

    config = vars(parser.parse_args())
    config['logstash_agent_name'] = sl_config['logstash_agent_name']

    for logfile, byte_count in get_byte_counts(config).items():
        # Values need to be written in very specific format:
        # host/plugin_name/metric_name epoch_seconds:metric_value
        # metric_name needs to start with one of the types included in types.db file
        # metric_value has to match format specified for the metric_name
        # For example, these are some of the entries from that types.db
        #   counter                 value:COUNTER:U:U
        #   temperature             value:GAUGE:U:U
        #   uptime                  value:GAUGE:0:4294967295
        print "PUTVAL {0}/{1}/counter-{2} {3}:{4}".format(config['hostname'],
                                                 'logstash_progress',
                                                 logfile,
                                                 datetime.datetime.now().strftime('%s'),
                                                 byte_count)

if __name__ == '__main__':
    main()
