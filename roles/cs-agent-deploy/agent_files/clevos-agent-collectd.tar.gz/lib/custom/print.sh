#!/bin/bash

host=$(hostname)
cur_dir=`pwd`
val=$(ls -l $cur_dir | wc -l)
echo "PUTVAL $host/count N:$val"
