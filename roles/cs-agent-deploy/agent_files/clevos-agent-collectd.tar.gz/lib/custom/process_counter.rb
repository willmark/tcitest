#!/usr/bin/env ruby

#IBM Confidential 2016
#Author: Amos Omokpo
#Email: aaomokpo@us.ibm.com

require 'rubygems' rescue LoadError
require 'optparse'

module Logstash
  class ProcessCounter

    PLUGIN_NAME = self.class.name.demodulize

    def initialize(config)
      @hostname = config[:hostname]
      @base_path = config[:base_path]
      @datacenter = config[:datacenter]
      @environment = config[:environment]
      @node_type = config[:node_type]
      @reset_counter = config[:reset_counter]
    end

    def get_bytes_count
      bytes_count_per_log = {}
      get_log_types(get_logstash_base_path!).each { |log_type|
        current_count = read_current_bytes(log_type)
        max_count = read_file_cache!(log_type)
        if self.reset_counter
          bytes_count_per_log[log_type] = current_count
          write_file_cache!(log_type, current_count)
        else
          bytes_count_per_log[log_type] = max_count + current_count
          write_file_cache!(log_type, max_count + current_count)
        end
      }
      bytes_count_per_log
    end

    private
      def get_log_types(file_path)
        log_type_pattern = /.*_(\w+)\.log$/
        log_types = []
        Dir.entries(file_path).each { |log_filename|
          log_filename.match(log_type_pattern) do |match|
            log_types << match.to_s
          end
        }
        log_types
      end

      def read_current_bytes(log_type)
        begin
          sincedb_line = `tail -n 1 #{get_sincedb_filename(log_type)}`
          space_character = " "
          sincedb_line_split = sincedb_line.split(space_character)
          bytes_line_index = 2
          return sincedb_line_split[bytes_line_index]
        rescue StandardError => e
          puts e.message
        end
      end

      def get_sincedb_filename(log_type)
        "#{get_logstash_base_path!}.sincedb_#{log_type}.log"
      end

      def sincedb_file_exist?(log_type)
        File.exist? "#{get_logstash_base_path!}.sincedb_#{log_type}.log"
      end

      def read_file_cache!(log_type)
        begin
          if file_cache_exist?(log_type)
            file_cache = File.open(file_cache_filename(log_type), 'r')
            value = file_cache.readline(0)
            file_cache.close()
            return value
          end
        rescue StandarError => e
          puts e.message
        end
      end

      def write_file_cache!(log_type, value)
        begin
          file_name = file_cache_filename(log_type)
          file_cache = File.open(file_name, 'w+')
          file_cache.write(value)
          file_cache.close()
          return file_name
        rescue StandarError => e
          puts e.message
        end
      end

      def file_cache_exist?(log_type)
        File.exist? file_cache_filename(log_type)
      end

      def file_cache_filename(log_type)
        "#{get_logstash_base_path!}.cache_#{log_type}.cache"
      end

      def get_logstash_base_path!
        if Dir.exist?(self.base_path) and self.node_type and self.datacenter and self.environment
          "#{self.base_path}logstash_#{self.node_type}_#{self.datacenter}_#{self.environment}/"
        else
          raise 'Set environment variables BASE_PATH, NODE_TYPE, DATACENTER and ENVIRONMENT.'
        end
      end
  end
end

# Main Script
begin
  # Setup configurations based on set options or defaults.
  config = {}

  config[:hostname] = 'localhost'
  config[:base_path] = '/lib/live/mount/medium/persistent/external-agent-multi/current/'
  config[:datacenter] = nil
  config[:environment] = nil
  config[:node_type] = nil
  config[:reset_counter] = false

  options = OptionParser.new do |opts|

    opts.banner = 'Usage: ' + __FILE__ + '[options]'
    opts.separator ""
    opts.separator 'Specific options:'

    opts.on('-H', '--optional STR', 'Sets the host name of running instance. [localhost] default: localhost') do |host_name|
      config[:hostname] = host_name
    end

    opts.on('-p', '--optional STR', 'Base path of running instance.') do |base_path|
      config[:base_path] = base_path
    end

    opts.on('-u', '--required STR', 'Datacenter of running instance.') do |datacenter|
      config[:datacenter] = datacenter
    end

    opts.on('-P', '--required STR', 'Environment of running instance.') do |environment|
      config[:environment] = environment
    end

    opts.on('-m', '--required STR', 'Node type/role of running instance.') do |node_type|
      config[:node_type] = node_type
    end

    opts.on('-r', '--optional --[no-]reset-counter', 'Reset bytes counter for every new tailed file. [true|false] default: false') do |reset_counter|
      config[:reset_counter] = reset_counter
    end

    opts.on('--help','print usage') do
      puts opts
      puts "\n"
      exit 0
    end
  end

  options.parse!(ARGV)

  # Collection loop
  process_counter = ProcessCounter.new(config)

  process_counter.get_bytes_count.each { |log_type, byte_count|
    puts("PUTVAL #{process_counter.hostname}/#{ProcessCounter::PLUGIN_NAME}/#{log_type} #{Time.now.to_i}:#{byte_count}")
  }
end
